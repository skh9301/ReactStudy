// useEffect - componentDidMount와 componentDidUpdate
import { useState, useEffect } from 'react'

const EffectComponent02 = (props) => {  
  const [num, setNum] = useState(0);  
  const incrementNum = () => setNum(num + 1);

  // useEffect Hook을 사용해서 렌더링 이후에 실행할 함수를 콜백 함수 안에서
  // 호출하도록 작성하면 된다. 또한 두 번째 인수로 상태(state)를 지정할 수
  // 있으며 state 변수를 지정하면 해당 state의 값이 변경될 때 마다 useEffect()
  // 함수에 지정한 콜백 함수가 호출된다. 아래와 같이 두 번째 인수를 지정하지
  // 않으면 화면이 렌더링될 때 마다 콜백 함수가 실행 된다. 즉 화면이 표시될
  // 때(componentDidMount)와 state가 변경될 때(componentDidUpdate) 마다 화면이
  // 렌더링되므로 useEffect() 함수에 지정한 콜백 함수가 호출된다.
  useEffect(() => {    
    console.log("화면이 렌더링 됨", num);
  });

  return (
    <div>
      <h3>{props.name} - {num}</h3>
      <button onClick={incrementNum}>클릭</button>     
    </div>
    );
}

export default EffectComponent02;