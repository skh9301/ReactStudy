// useEffect - Too many re-renders 오류
import { useState } from 'react'

const EffectComponent01 = (props) => {
  // 이 코드는 실행과 동시에 num 상태(state) 값이 setNum에 의해서
  // 변경되면서 다시 렌더링 되고 또 다시 setNum에 의해서 state가 
  // 변경되는 것을 무한 반복하기 때문에 오류가 발생한다.
  const [num, setNum] = useState(0)
  setNum(num + 1);
  console.log("화면이 렌더링 됨")

  return (
    <div>
      <h3>{props.name} - {num}</h3>
    </div>
    );
}

export default EffectComponent01;