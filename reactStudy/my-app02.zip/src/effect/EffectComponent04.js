// useEffect - componentDidUpdate
import { useState, useEffect } from 'react'

const EffectComponent04 = (props) => {
  const [num, setNum] = useState(0);
  const [name, setName] = useState(props.name);
  const incrementNum = () => setNum(num + 1);
  const updateName = () => setName(name + num);

  // useEffect() 함수의 두 번째 인수로 state 변수를 지정하면 해당 state 
  // 값이 변경될 때(componentDidUpdate) 마다 useEffect() 함수에 지정한
  // 콜백 함수가 호출 된다.
  useEffect(() => {
    console.log("화면이 렌더링 됨", name)
  }, [name]);
  
  return (
    <div>
      <h3>{name} - {num}</h3>
      <button onClick={incrementNum}>숫자 증가</button>
      <button onClick={updateName}>이름 변경</button>
    </div>
    );
}

export default EffectComponent04;