// 컴포넌트의 이름은 반드시 대문자로 시작해야 한다. 그렇지 않으면 동작하지 않는다.
// Ract의 함수형 컴포넌트는 생김새가 자바스크립트 함수와 같으며 props라는
// 임의의 입력을 받고 화면에 표시되는 엘리먼트(React Element)를 반환한다.
function ChildComponent(props) {
  // props는 함수형 컴포넌트의 첫 번째 매개변수로 전달된다.
  return <li>자식 컴포넌트 - { props.name } 입니다.</li>
}

export default ChildComponent;