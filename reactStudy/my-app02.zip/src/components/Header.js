function Header(props) {
  return (    
    <header className="header">
      <h3>여기는 Header</h3>
      <nav>
        <ul>
          <li>홈</li>
          <li>회원가입</li>
          <li>로그인</li>
        </ul>
      </nav>
    </header>    
  );
}

export default Header;