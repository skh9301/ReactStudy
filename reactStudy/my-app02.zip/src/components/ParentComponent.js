import Child from './ChildComponent.js';

function ParentComponent(props) {
  return (
    <div className="parent">
      <h2>여기는 부모 컴포넌트</h2>
      <div>
        <h3>{props.title}</h3>
        <ul>
          {/* props는 프로퍼티(Properties)의 줄임 말로 상위 컴포넌트에서 하위 컴포넌트로
              값을 전달할 때 사용한다. props는 상위에서 하위로 단방향 데이터 흐름을 가지며
              자식 컴포넌트에서 값을 변경할 수 없고 단지 읽을 수 있다. */}
          <Child name="FirstChild" />
          <Child name="SecondChild" />
        </ul>
      </div>
    </div>
  );
}

export default ParentComponent;