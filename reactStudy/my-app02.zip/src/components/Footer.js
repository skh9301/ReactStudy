function Footer(props) {
  return (
    <footer className="footer">
      <h3>여기는 Footer</h3>
    </footer>
  );
}

export default Footer;