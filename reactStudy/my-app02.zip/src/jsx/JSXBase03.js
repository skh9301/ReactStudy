// JSX(JavaScropt XML) - React DOM Element의 속성과 인라인 스타일
export function ElememtProperty01(props) {
  return (
    // JSX에서 React 엘리먼트의 속성은 카멜 표기법(Camel Case)을 사용하며
    // HTML에서 사용하는 class 속성은 다음과 같이 className 속성을 사용한다.
    <div className="primary">
      {/* props는 객체로 전달되므로 다음과 같이 접근 할 수 있다. */}
      <h3>엘리먼트의 속성은 {props.title} 사용</h3>
      
      {/* label 태그의 for 속성은 for 키워드와 중복되어 JSX에서 htmlFor를 사용함 */}
      <label htmlFor="id">아이디 : </label>
      <input type="text" id="id" name="id" />
    </div>
  );
}

export function ElememtProperty02(props) {
  // React에서 인라인 스타일을 적용할 때 CSS 속성도 카멜 표기법을 사용한다. 
  const style = {
    fontSize: '20px',
    backgrounColor: 'red',
    width: '300px',
    textAlign: 'center'
  }
  return (
    // 인라인 스타일은 주로 DOM이 렌더링될 때 동적으로 스타일을 적용하기 위해서 
    // 사용되며 선택자를 통해 CSS style을 정의하여 사용하는 방식이 주로 사용된다.
    <>
      <p style={style}>{props.msg}</p>
    </>
  )
}