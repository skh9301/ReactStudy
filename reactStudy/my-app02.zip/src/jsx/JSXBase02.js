// JSX(JavaScropt XML) - 자바스크립트 표현식을 중괄호로 감싸서 사용
export function Expression01() {  
  const msg = "Hi React JSX";
  const url = "/logo192.png";

  return (
    <div>
      {/* 여기는 JSX 주석
          JSX 문장 안에서 자바스크립트 변수, 함수 호출 등의 
          자바스크립트 표현식을 중괄호로 감싸서 사용할 수 있음 */}
      <div>{msg}</div>      
      <img src={url} /> {/* 빈 태그는 셀프 클로징을 받드시 해야함 */}
      <a href="http://www.naver.com">네이버 가기</a><br/>
    </div>
  );
}

export function Expression02() {
  const mem = {id: 'midas', pass: '1234'};

  function getMessage(name) {
    // 함수의 반환 값으로 JSX 문법 사용
    return <h3>Hi {name}</h3>;
  }

  return (
    <>  {/* 객체의 속성 출력과 함수 호출도 중괄호 사용 */}
      <div>{mem.id} - {mem.pass}</div>    
      <div>{getMessage("홍길동")}</div>
    </>
  );
}

export function Expression03() {
  let msg = "";
  const isLogin = true; 

  // JSX 문법에서 if, for 문을 사용할 수 없기 때문에
  // JSX 문장 밖에서 별도로 처리한 후에 결과를 사용
  if(isLogin) {
    msg = <h3>안녕하세요 고객님~</h3>;
  }else {
    msg = <h3>로그인이 필요한 서비스 </h3>
  }

  return (
    <>
      { msg }
    </>
  );
}

export function Expression04() {  
  const isLogin = false;

  return (
    <>
      {/* JSX 안에서 삼 항 연산자 사용 */}
      { isLogin ? (<h3>안녕하세요 고객님~</h3>) 
            : (<h3>로그인이 필요한 서비스</h3>) }
    </>
  );
}