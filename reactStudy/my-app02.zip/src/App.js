// map() 함수를 사용해 Component 배열 다루기2 - 객체 배열
import './App.css';
import Member from './map/MapComponent02';

function App() {
  // map() 함수를 사용해 객체 배열의 내용을 MemberComponent에 적용해 MemberComponent 배열을 생성 
  const members = [
    { id: 'hong', name: "홍길동", age: 30 },
    { id: 'ohho', name: "어머나", age: 33 },
    { id: 'leem', name: "임꺽정", age: 27 }
  ];

  return (
    <div className="App">
      <ul>
        {/* map() 함수에서 DOM을 직접 생성해 반환 */}
        { 
          members.map((member, index) => 
            (<li key={ member.id }>{ member.id } - { member.name }({ member.age })</li>))
        }
      </ul>
      <ul>
        {/* map() 함수에서 하위 컴포넌트를 이용해 DOM을 생성해 반환 */}
        {
         members.map((member, index) => <Member key={ member.id } {...member} />)
        }
      </ul>
    </div>
  );
}

export default App;
