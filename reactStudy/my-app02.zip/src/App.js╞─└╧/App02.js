// 부모 컴포넌트와 자식 컴포넌트
import './App.css'
import ParentComponent from './components/ParentComponent';

function App() {
  return (
    <div className="App">      
      <ParentComponent title="자식 리스트" />      
    </div>
  );
}

export default App;