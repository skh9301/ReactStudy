// useEffect - componentDidUpdate
import './App.css';
import Effect04 from './effect/EffectComponent04'

function App() {
  return (
    <div className="App">
      <Effect04 name="Effect04"/>
    </div>
  );
}

export default App;
