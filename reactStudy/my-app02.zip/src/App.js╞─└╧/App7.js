// useState와 이벤트 처리
import './App.css';
import State01 from './state/StateComponent01'
import State02 from './state/StateComponent02'

function App() {
  return (
    <div className="App">
      <State01 msg="클릭해~"/>      
      <State02 msg="클릭해~"/>
    </div>
  );
}

export default App;
