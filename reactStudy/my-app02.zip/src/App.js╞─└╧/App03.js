// 컴포넌트 합성
import './App.css'
import ParentComponent from './components/ParentComponent';
import Header from './components/Header'
import Footer from './components/Footer'

function App() {
  return (
    <div className="App">
      <Header />
      <ParentComponent title="자식 리스트" />
      <Footer />
    </div>
  );
}

export default App;