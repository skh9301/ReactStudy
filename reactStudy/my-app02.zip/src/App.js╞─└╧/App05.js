// JSX(JavaScropt XML) - 자바스크립트 표현식을 중괄호로 감싸서 사용
// import 할 때 별칭을 지정해서 별칭 이름의 하위 속성으로 접근 할 있음
import * as JSX from './jsx/JSXBase02.js'

function App() {
  return (
    <div className="App">
     <JSX.Expression01 />
     <JSX.Expression02 />
     <JSX.Expression03 />
     <JSX.Expression04 />
    </div>
  );
}

export default App;
