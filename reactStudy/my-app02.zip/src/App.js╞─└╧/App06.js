// JSX(JavaScropt XML) - React DOM Element의 속성과 인라인 스타일
import './App.css'

// import 할 때 각각에 별칭을 지정해서 사용할 수 있음
import { ElememtProperty01 as Elem01, ElememtProperty02 as Elem02 } from './jsx/JSXBase03'

function App() {
  return (
    <div className="App">
      {/* 다음과 같이 부모 컴포넌트에서 자식 컴포넌트를 사용할 때 프로퍼티(props)에
          지정한 값은 자식 컴포넌트 함수의 첫 번째 매개변수로 전달된다. */}
      <Elem01 title="카멜 표기법"/>
      <Elem02 msg="인라인 스타일 적용하기"/>
    </div>
  );
}

export default App;
