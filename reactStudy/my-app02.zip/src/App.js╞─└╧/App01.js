// 클래스 컴포넌트와 함수 컴포넌트
import './App.css'
import { WelcomeClass, WelcomeFunction } from './components/Welcome'

function App() {
  return (   
    // React에서 요소의 클래스 속성은 className을 사용한다. 
    <div className="App">
      <WelcomeClass name="React" />
      <WelcomeFunction name="React" />
    </div>
  );
}

export default App;