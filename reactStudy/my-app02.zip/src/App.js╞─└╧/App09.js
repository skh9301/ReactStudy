// useEffect - componentDidMount와 componentDidUpdate
import './App.css';
import Effect02 from './effect/EffectComponent02'

function App() {
  return (
    <div className="App">
      <Effect02 name="Effect02"/>
    </div>
  );
}

export default App;
