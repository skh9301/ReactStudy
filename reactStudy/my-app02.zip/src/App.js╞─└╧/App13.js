// map() 함수를 사용해 Component 배열 다루기1
import './App.css';
import Member from './map/MapComponent01';

function App() {
  // map() 함수를 사용해 배열의 내용을 MemberComponent에 적용해 MemberComponent 배열을 생성 
  const members = ['홍길동', '임꺽정', '어머나'];
  // const mList = members.map((name, index) => (<Member name={name} />));
  const mList = members.map((name, index) => (<Member key={name} name={name} />));

  return (
    <div className="App">
      <ul>
        {mList}
      </ul>
    </div>
  );
}

export default App;
