// useEffect - componentDidMount
import './App.css';
import Effect03 from './effect/EffectComponent03'

function App() {
  return (
    <div className="App">
      <Effect03 name="Effect03"/>
    </div>
  );
}

export default App;
