// 반복적인 작업에 JavaScript 배열의 map() 함수 사용하기
import './App.css';

function App() {
  const nums = [1, 3, 5, 7, 9];
  const result = [];

  const useFor = () => {
    for(let i = 0; i < nums.length; i++) {
      result.push(nums[i] * 2);
    }  
    console.log(result);
  };

  const useMap = () => {
    // 배열의 각 요소를 원하는 규칙에 따라 적용한 후 새로운 배열로 반환
    const items = nums.map((value, index, array) => {
      return value * 2
    });
    console.log(items);
  }; 

  useFor();
  useMap();
  
  return (
    <div className="App"></div>
  );
}

export default App;
