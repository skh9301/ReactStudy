// useEffect - Too many re-renders 오류
import './App.css';
import Effect01 from './effect/EffectComponent01'

function App() {
  return (
    <div className="App">
      <Effect01 name="Effect01"/>
    </div>
  );
}

export default App;
