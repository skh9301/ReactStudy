// JSX(JavaScropt XML) - 컴포넌트 내부는 하나의 DOM 트리 구조를 가져야 함
import { JSXBase02, JSXBase03, JSXBase04 } from './jsx/JSXBase01'

function App() {
  return (
    <div className="App">
      {/* 여기는 JSX의 주석
          JSX는 자바스크립트에 XML 문법을 결합한 확장 문법으로 규칙이 엄격하다. 
          다음과 같이 내용이 없는 빈 요소는 반드시 셀프 클로징을 해야 한다. */}
      {/* <JSXBase01 /> */}
      <JSXBase02 />
      <JSXBase03 />
      <JSXBase04 />
    </div>
  );
}

export default App;
