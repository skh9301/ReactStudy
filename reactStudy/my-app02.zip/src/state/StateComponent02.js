// useState를 사용하는 함수 컴포넌트
import React from 'react'
function StateComponent02(props) {
  // 데이터가 변경되어 화면을 다시 렌더링하려면 함수 컴포넌트에서는 
  // React Hook에서 제공하는 useState() 함수를 사용해서 상태(state)가
  // 변경되었음을 알려줘야 React가 화면을 다시 렌더링 하게 된다.
  // 다음과 같이 React의 useState() 함수를 호출하면서 초기 값을 인수로 지정하고
  // 상태로(state)로 사용할 변수와 이 상태(state)를 변경하는 setter 함수를
  // 지정하고 값이 변경될 때 이 setter 함수를 이용해 값을 변경해 주면 된다.
  // state는 문자열, 숫자, boolean, 배열, null, 객체 등의 다양한 값을 가질 수 있고
  // 초기 값은 처음 렌더링할 때 한 번만 사용된다. 
  const [num, setNum] = React.useState(0);
  
  function updateNum() {
    setNum(num + 1);
    console.log(num);
  }
  return (
    <div className="area">      
      <h3>{ num }</h3>
      {/* 클릭할 때 마다 updateNum() 함수가 호출됨 */}
      <button onClick={updateNum}>{props.msg}</button>
    </div>
  );
}

export default StateComponent02;