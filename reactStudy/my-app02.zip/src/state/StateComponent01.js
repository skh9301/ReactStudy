// useState를 사용하지 않는 경우의 함수 컴포넌트
function StateComponent01(props) {
  let num = 0;
  function updateNum() {    
    num += 1;
    console.log(num);
  }
  
  return (
    <div className="area">
      <h3>{ num }</h3>      
      {/* 클릭할 때 마다 updateNum() 함수가 호출된다. 
          React의 이벤트는 소문자 대신 카멜 케이스(Camel Case)를 사용한다.
          JSX를 사용해서 이벤트 핸들러를 등록할 때는 함수 호출 표현식을
          문자열로 지정하는 것이 아니라 함수를 이벤트 핸들러로 전달한다. */}
      <button onClick={updateNum}>{props.msg}</button>
    </div>
  );
}

export default StateComponent01;