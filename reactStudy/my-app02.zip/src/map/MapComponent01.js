// map() 함수를 사용해 Component 배열 다루기1
const MemberComponent = (props) => {
  return (
    <>
      <li>안녕하세요 { props.name }</li>
    </>
  );
}

export default MemberComponent