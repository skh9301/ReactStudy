// map() 함수를 사용해 Component 배열 다루기2 - 객체 배열
// props는 member 객체를 받기 때문에 객체 구조 분해 할당을 사용함
  const MemberComponent = ({ id, name, age }) => {
  return (
    <>
      <li>{ id } - { name }({ age })</li>
    </>
  );
}

export default MemberComponent