import './App.css';
import BoardListPage from './pages/BoardListPage';

function App() {

  return (
    <div className="container"> 
      <BoardListPage />
    </div>
  );
}

export default App;
