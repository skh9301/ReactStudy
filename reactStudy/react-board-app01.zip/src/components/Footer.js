export default function Footer() {
  return (
    // footer
    <div className="row border-top border-primary my-5">
      <div className="col text-center py-3">
        <p>고객상담 전화주문:1234-5678 사업자등록번호 :111-11-123456  
      대표이사: 홍길동  통신판매업 서울 제 000000호<br/>
      개인정보관리책임자:임꺽정 분쟁조정기관표시 : 소비자보호원, 전자거래분쟁중재위원회<br/>      	
      Copyright (c) 2016 Spring2U Corp. All right Reserved.	
        </p>
      </div>
    </div>
  )
}