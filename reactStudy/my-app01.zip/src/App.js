function App() {
  return (
    <div className="App">
      <h1>React 프로젝트 만들기</h1>
      <h3>React 주요 특징</h3>
      <ul>
        <li>가상 돔(Virtual DOM)</li>
        <li>JSX(JavaScript XML)</li>
        <li>컴포넌트(Component)</li>
        <li>Props & State</li>
      </ul>
    </div>
  );
}

export default App;
